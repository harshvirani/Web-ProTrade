# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Website for Pro-Trade

### How do I get set up? ###

You will require rethinkdb, mysql, and working internet connection.

### Contribution guidelines ###

Sharad Paghadal
Harsh Virani
Gaurang Ribadiya

### Who do I talk to? ###

sharad.appdeveloper@gmail.com