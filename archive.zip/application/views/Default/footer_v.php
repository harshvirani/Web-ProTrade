
</div>
<script src="https://code.getmdl.io/1.3.0/material.min.js"></script>
     

    <script src="<?php echo base_url().NAV_ASSETS; ?>js/index.js"></script>
    <!--<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-alpha1/jquery.min.js'></script>-->
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/4579/list.min.js'></script>

    <script src="<?php echo base_url().NAV_ASSETS; ?>js/search.js"></script>
      
    </body></html>