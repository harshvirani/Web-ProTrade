<main class="mdl-layout__content">
    <h1>DASHBOARD</h1>
</main>